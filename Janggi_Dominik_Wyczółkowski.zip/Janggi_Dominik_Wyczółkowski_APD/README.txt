APLIKACJA DO GRY W JANGGI
Autor: Dominik Wyczółkowski

Praca licencjacka:
„Projekt i implementacja aplikacji do gry w Janggi
z elementami sztucznej inteligencji”

URUCHOMIENIE APLIKACJI

Gotową wersję programu można uruchomić za pomocą pliku:

aplikacja\Janggi\Janggi.exe

Aplikacja przeznaczona jest dla systemu Windows.

KOD ŹRÓDŁOWY

Kod źródłowy aplikacji znajduje się w folderze:

kod_zrodlowy

Głównym plikiem programu jest janggi.py.

Do uruchomienia programu bezpośrednio z kodu źródłowego
wymagany jest Python oraz biblioteka Pygame.

Bibliotekę można zainstalować poleceniem:

pip install -r requirements.txt